import hashlib,json,os,pathlib,resource,shutil,socket,subprocess,sys,tempfile,time
sys.path.insert(0,str(pathlib.Path.cwd()/'scripts'))
from run_cli import memory_cap,stop_group,now
root=pathlib.Path.cwd(); plan=json.load(open('results/runs/e1-bprna-long-89baea52-20261018/array_plan.json'));config=plan['config'];build=root/'build/linear-cparty-89baea52';software=root/'deps/LinearCParty-89baea52'
name=sys.argv[1];label=sys.argv[2];timeout=int(sys.argv[3]);item=next(i for i in plan['inputs'] if i['name']==name)
work=pathlib.Path(tempfile.mkdtemp(prefix='e1-long-cpu16-'+label+'-',dir=os.environ['TMPDIR']))
shutil.copyfile(item['source_path'],work/'input.txt');shutil.copyfile(software/config['energy_parameter_file'],work/'params.par')
program=next(p for p in config['programs'] if p['name']==(sys.argv[4] if len(sys.argv)>4 else 'LinearCParty'));mode=config['modes'][-1]
command=[str(build/program['name']),'-i',str(work/'input.txt'),*mode['args'],*program['args']]
for product in program.get('outputs',[]):command.extend([product['flag'],str(work/product['name'])])
env={**os.environ,**config['environment'],'CPARTY_FIXED_ENERGY_PARAM_FILE':str(work/'params.par')}
started=time.monotonic();start_utc=now();rss=0;vms=0;status='success';samples=[]
print('Started',label,name,item['length'],'cap4096',timeout,'s',work,flush=True)
with (work/'stdout.txt').open('wb') as out,(work/'stderr.txt').open('wb') as err:
    process=subprocess.Popen(['/usr/bin/time','-f','%e\t%M','-o',str(work/'time.tsv'),'--',*command],stdout=out,stderr=err,env=env,cwd=work,preexec_fn=memory_cap(4096),start_new_session=True)
    while process.poll() is None:
        try:
            children=(pathlib.Path('/proc')/str(process.pid)/'task'/str(process.pid)/'children').read_text().split()
            for pid in children:
                fields={x.split(':',1)[0]:x.split(':',1)[1].split() for x in (pathlib.Path('/proc')/pid/'status').read_text().splitlines() if ':' in x}
                rss=max(rss,int(fields.get('VmHWM',['0'])[0]));vms=max(vms,int(fields.get('VmPeak',['0'])[0]))
        except (OSError,ValueError):pass
        elapsed=time.monotonic()-started
        if not samples or elapsed-samples[-1]['elapsed_seconds']>=30:
            samples.append({'elapsed_seconds':elapsed,'sampled_peak_rss_kib':rss,'sampled_peak_vm_kib':vms});print('progress',label,json.dumps(samples[-1]),flush=True)
        if elapsed>=timeout:status='timeout';stop_group(process);break
        time.sleep(.2)
returncode=process.wait();elapsed=time.monotonic()-started
if returncode and status=='success':status='failed'
wall=None;gnu_rss=None
if (work/'time.tsv').exists():
    for line in (work/'time.tsv').read_text().splitlines():
        try:
            w,r=line.split('\t');wall=float(w);gnu_rss=int(r)
        except ValueError:pass
result=dict(input=name,length=item['length'],mode=mode['name'],program=program['name'],status=status,returncode=returncode,elapsed_seconds=elapsed,time_wall_seconds=wall,peak_rss_kib=gnu_rss,sampled_peak_rss_kib=rss,sampled_peak_vm_kib=vms,memory_limit_mib=4096,timeout_seconds=timeout,input_sha256=item['sha256'],binary_sha256=hashlib.sha256((build/program['name']).read_bytes()).hexdigest(),command=command,hostname=socket.gethostname(),workspace=str(work),started_utc=start_utc,finished_utc=now(),samples=samples,purpose='development scheduling pilot; single process, not isolated cpu_16 throughput')
(work/'result.json').write_text(json.dumps(result,indent=2)+'\n');(pathlib.Path(os.environ['TMPDIR'])/('e1_long_cpu16_'+label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print('Finished',label,json.dumps({k:v for k,v in result.items() if k not in ('samples','command')}),flush=True)
