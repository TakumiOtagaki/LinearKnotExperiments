import copy,io,json,os,shutil,sys,tarfile
from pathlib import Path
ROOT=Path('/gs/bs/tga-satolab-gtex/otgk/LinearCPartyPaper/experiments');sys.path.insert(0,str(ROOT/'scripts'))
from run_cli import run_one,digest,git_state,now,write_json
from compare_release_outputs import compare_bytes
from task_storage import local_workspace
out=ROOT/'results/local/linearknot-9c7d6e1-comparison-20261020'
initial=out.with_name(out.name+'-initial8g')
report=json.loads((out/'comparison.json').read_text());assert report['status']=='complete'
failed=[r for r in report['rows'] if not r['successful']]
assert len(failed)==2 and all(r['input']=='bpRNA_RFAM_39964' and r['mode']=='exact' and r['command'] in ('sample','sample-unique') for r in failed)
assert not initial.exists()
receipt=json.loads((ROOT/'manifests/release-preparation-linearknot-9c7d6e1.json').read_text())
report['initial_comparison_script_sha256']=receipt['workflow_scripts_sha256']['scripts/compare_linearknot_outputs.py']
out.rename(initial);out.mkdir()
for name in ('raw_outputs.tar','processes.jsonl'):shutil.copyfile(initial/name,out/name)
report.update(status='retrying',initial_report=str(initial/'comparison.json'),initial_report_sha256=digest(initial/'comparison.json'),
    initial_memory_limit_mib=8192,retry_memory_limit_mib=16384,retry_started_utc=now(),retry_script_sha256=digest(Path(__file__)))
write_json(out/'comparison.json',report)
env={k:v for k,v in os.environ.items() if not k.startswith('CPARTY_')};env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',LC_ALL='C')
with local_workspace() as work,tarfile.open(ROOT/report['input_archive']) as inputs,tarfile.open(out/'raw_outputs.tar','a') as archive,(out/'processes.jsonl').open('a') as log:
 item=next(i for i in report['inputs'] if i['name']=='bpRNA_RFAM_39964')
 member=next(m for m in inputs if m.isfile() and Path(m.name).name==item['name']+'.txt')
 source=work/'input.txt';source.write_bytes(inputs.extractfile(member).read());assert digest(source)==item['sha256']
 parameter=work/'energy.par';parameter.write_bytes((ROOT/'deps/LinearCParty-89baea52/params/rna_Turner04.par').read_bytes());env['CPARTY_FIXED_ENERGY_PARAM_FILE']=str(parameter)
 for old in failed:
  row={k:old[k] for k in ('input','input_sha256','mode','command')};row['prior_attempt']=old;row['memory_limit_mib']=16384;row['attempt']=2;outputs={}
  for side in ('reference','candidate'):
   directory=work/side;directory.mkdir()
   argv=list(old[side]['argv']);argv[argv.index('-i')+1]=str(source)
   result=run_one(argv,directory,env,180,memory_limit_mib=16384);row[side]={**result,'argv':argv}
   log.write(json.dumps({'input':row['input'],'mode':row['mode'],'command':row['command'],'side':side,'attempt':2,'memory_limit_mib':16384,**row[side]})+'\n');log.flush()
   outputs[side]={}
   for name in ('stdout.txt','stderr.txt'):
    data=(directory/name).read_bytes();outputs[side][name]=data
    info=tarfile.TarInfo('/'.join((row['input'],row['mode'],row['command'],side,name)));info.size=len(data);archive.addfile(info,io.BytesIO(data))
   shutil.rmtree(directory)
  row['files']={n:compare_bytes(outputs['reference'][n],outputs['candidate'][n]) for n in outputs['reference']}
  row['successful']=all(row[s]['status']=='success' for s in outputs);row['identical']=row['successful'] and all(f['identical'] for f in row['files'].values())
  idx=report['rows'].index(old);report['rows'][idx]=row
  write_json(out/'comparison.json',report);print(row['command'],row['successful'],row['identical'],flush=True)
for side,src,build in [('reference','deps/LinearCParty-89baea52','build/linear-cparty-89baea52'),('candidate','deps/LinearKnot-9c7d6e1','build/linearknot-9c7d6e1')]:
 f=report['fingerprints'][side];assert f['source']==git_state(ROOT/src);assert f['cmake_cache_sha256']==digest(ROOT/build/'CMakeCache.txt');assert f['binaries']=={n:digest(ROOT/build/n) for n in f['binaries']}
report.update(status='complete',finished_utc=now(),successful=all(r['successful'] for r in report['rows']),identical=all(r['identical'] for r in report['rows']),identical_comparisons=sum(r['identical'] for r in report['rows']),total_process_attempts=760,retried_comparisons=2,
    artifacts_sha256={n:digest(out/n) for n in ('raw_outputs.tar','processes.jsonl')})
write_json(out/'comparison.json',report)
print('final',report['successful'],report['identical_comparisons'],flush=True)
