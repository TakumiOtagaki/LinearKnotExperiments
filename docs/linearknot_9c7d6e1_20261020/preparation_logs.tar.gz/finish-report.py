import json
import os
from pathlib import Path
import sys
import tarfile

ROOT = Path('/gs/bs/tga-satolab-gtex/otgk/LinearCPartyPaper/experiments')
sys.path.insert(0, str(ROOT / 'scripts'))
from summarize_linearknot_comparison import audit
from run_cli import digest, now, write_json
from plan_array import load_plan

work = Path(os.environ['TMPDIR']) / 'linearknot-pin-20261020'
doc = ROOT / 'docs/linearknot_9c7d6e1_20261020'
directory = ROOT / 'results/local/linearknot-9c7d6e1-comparison-20261020'
raw = json.loads((directory / 'comparison.json').read_text())
assert raw['status'] == 'complete' and raw['successful']
assert raw['comparisons'] == raw['planned_comparisons'] == 378
processes = [json.loads(l) for l in (directory / 'processes.jsonl').read_text().splitlines()]
assert len(processes) == 760 and sum(r['status'] != 'success' for r in processes) == 2
assert all(row['successful'] for row in raw['rows'])
summary = audit(directory)
write_json(doc / 'comparison_summary.json', summary)

result = ('数値・構造・BPP・sampling の出力は一致し、差は access の名称2行だけだった。'
          if summary['all_identical_after_metadata_rename'] else
          '名称2行の置き換え以外にも差が残った。comparison_summary.json と各条件の差の例を参照する。')
paragraph = f'''初回の8 GiB上限では旧版の exact sampling 2件が `std::bad_alloc` で停止した。
その2条件を双方16 GiBで再実行すると4プロセスとも成功した。
各条件の最終実行では全378条件・756プロセスが正常終了した。
実際の実行回数は760で、初回の失敗2件も保存した。timeoutは0だった。
経過時間行を除く strict byte 一致は **{summary['byte_identical']}/378条件**だった。
{result}
2行の名称だけを対応させた照合は **{sum(r['identical_after_metadata_rename'] for r in summary['by_command'].values())}/378条件**で一致した。

| 出力 | strict byte 一致 | 名称2行を対応させた一致 |
|---|---:|---:|
'''
for name, row in summary['by_command'].items():
    paragraph += f"| {name} | {row['byte_identical']}/{row['comparisons']} | {row['identical_after_metadata_rename']}/{row['comparisons']} |\n"
paragraph += '\n'
p = doc / 'README.md'
s = p.read_text()
needle = '集計は [comparison_summary.json](comparison_summary.json) を参照する。\n'
assert needle in s and 'strict byte 一致は **' not in s
p.write_text(s.replace(needle, paragraph + needle))

prep = json.loads((ROOT / 'docs/centroid_89baea52_20261020/preparation.json').read_text())
for name, expected in prep['files_sha256'].items():
    assert digest(ROOT / name) == expected, name
for variant in prep['variants']:
    plan = load_plan(ROOT / variant['plan'])
    for task in plan['tasks']:
        path = Path(plan['output_dir']) / task['directory']
        metadata = json.loads((path / 'task.json').read_text())
        assert metadata['status'] == 'not_started' and not metadata['attempts'] and not (path / 'run').exists()
assert not (ROOT / 'results/local/e0-decoding-centroid-89baea52-20261020').exists()

with tarfile.open(doc / 'preparation_logs.tar.gz', 'w:gz') as archive:
    for path in sorted(work.iterdir()):
        if path.suffix in ('.log', '.json', '.py') or path.name == 'centroid-probe-smoke.tar':
            archive.add(path, arcname=path.name)
receipt_path = ROOT / 'manifests/release-preparation-linearknot-9c7d6e1.json'
receipt = json.loads(receipt_path.read_text())
receipt['workflow_scripts_sha256']={n:digest(ROOT/n) for n in receipt['workflow_scripts_sha256']}
receipt.update(finished_utc=now(), comparison=dict(
    directory=str(directory), successful=raw['successful'], strict_identical=raw['identical'],
    identical_comparisons=summary['byte_identical'], comparisons=378, processes=756,
    identical_after_metadata_rename=summary['all_identical_after_metadata_rename'],
    summary_sha256=digest(doc / 'comparison_summary.json'),
    report_sha256=digest(directory / 'comparison.json'), total_process_attempts=760, initial_failed_processes=2, retry_memory_limit_mib=16384),
    preparation_logs_sha256=digest(doc / 'preparation_logs.tar.gz'))
write_json(receipt_path, receipt)

english = f'''

## 2026-10-20 LinearKnot pin, release parity and centroid preparation

- Pinned LinearKnot `9c7d6e170b2b21a94a2e626d9939817e62898253` in `deps/LinearKnot-9c7d6e1` and built Release in `build/linearknot-9c7d6e1` with `-j8`, tests enabled and LTO disabled per the maintained test guide. The maintained suite passed 87 checks plus its dependency gate; three selected lock checks and five Python tests passed. Source/tree, CLI, parameters, effective flags and build provenance are in `manifests/software-linearknot-9c7d6e1.json` and `manifests/release-preparation-linearknot-9c7d6e1.json`.
- Regression: the same 14 frozen release inputs, b20/b200/exact, fold/BPP, profile, access1/4/8/16 total/by-loop, sample normal/unique with identical seed, MEA/centroid gamma1 and Subopt top8. All 756 effective processes succeeded after retrying two exact sampling comparisons at 16 GiB (the old CLI hit the initial 8 GiB address-space cap). All 760 process attempts, including two initial failures, are retained; strict agreement after removing elapsed-time lines is {summary['byte_identical']}/378. Agreement after the two documented access metadata renames is {sum(r['identical_after_metadata_rename'] for r in summary['by_command'].values())}/378. See [the full report and CLI mapping](linearknot_9c7d6e1_20261020/README.md). Raw outputs remain one tar plus one process JSONL under `results/local/linearknot-9c7d6e1-comparison-20261020`; source/build fingerprints were unchanged.
- Prepared [centroid replacements](centroid_89baea52_20261020/README.md) on the adopted 89baea52 build: NEAT1 gamma1 at b100/200/400 (cpu_40, three workers, 20 GiB/process; h_rt 22 minutes and 2 h 50 minutes), full local Terc exact/b200 and Figure 1 exact matrices with MEA replaced, and a separate E0 decoding suite adding 6561 centroid objective checks and 6561 CLI records against enumeration. Gamma1 is ordinary centroid; its objective differs from MEA. Existing inputs, scaffold, other outputs, seeds and original plans are preserved.
- Verification: all four new matrix tasks and the E0 full suite remain unstarted; dependencies, frozen plans and seven shell scripts passed checks. A small E0 preparation smoke compiled the new probe and passed 27 API optimum/score checks plus 27 CLI checks, maximum error 2.842170943040401e-14. Full E0 is estimated at about 40 minutes in a 2-hour cpu_16 allocation. Initial suite cwd/parameter failure and the successful full rerun are retained in one log tar.
- Operations: checked quota before clone (21,567,719 / 28,000,000 files), kept planner inode checks enabled and all transient per-process files in TMPDIR. The clone/build use 833/2369 descendant entries. No scheduler submission, git commit, manuscript edit or modification to either external implementation checkout was made. Existing unrelated edits were preserved.
'''
with (ROOT / 'docs/progress.md').open('a') as f:
    f.write(english)
japanese = f'''

## 2026-10-20 LinearKnot の固定・旧版との比較と γ-centroid の準備

- LinearKnot `9c7d6e1` を実験 repo の `deps/LinearKnot-9c7d6e1` に固定し、`build/linearknot-9c7d6e1` に Release build と software lock を作成した。必須 suite の87項目と dependency gate、lock の3検査、Python tests 5件が成功。[固定・比較とCLI対応表](../experiments/docs/linearknot_9c7d6e1_20261020/README.md) に根拠と初回 cwd 失敗を含むログを保存した。
- 科学的な回帰結果：既存 receipt と同じ14入力の b20/b200/exact、9出力、378条件の最終実行・756 processがすべて正常終了した。初回8 GiBの仮想メモリ上限で旧sampling 2件が停止し、その2条件を双方16 GiBで再実行して一致を確認した。実際の760実行と初回失敗を保存した。経過時間行を除くbyte一致は{summary['byte_identical']}/378。accessの名称2行だけを対応させると{sum(r['identical_after_metadata_rename'] for r in summary['by_command'].values())}/378が一致した。数値・構造・BPP・samplingの差の有無は同報告の全件照合に記録した。論文の採用数値は89baea52のまま保持する。
- [γ-centroid 用の設定・実行コマンドと見積もり](../experiments/docs/centroid_89baea52_20261020/README.md) を準備した。採用版89baea52で NEAT1 の両isoform・b100/200/400、Terc exact/b200、Figure 1 exact の MEA を γ=1 centroid に置換。γ=1 が通常のcentroidであり、MEAとは目的関数が異なる。NEAT1 は前回と同じcpu_40・3 workers・20 GiB/process、h_rtは実績の約2倍（22分・2時間50分）。E0の別コピーには列挙分布からの6561目的値照合と6561CLIレコード照合を追加し、約40分・cpu_16の2時間枠を見込む。
- 開発上の検証：小入力3件の27 API・27 CLI照合が成功し、最大誤差2.842170943040401e−14。依存hash、実行可能なfrozen plan、shell構文を検査した。新matrixの4 taskとE0全件は未実行。inodeを確認し、一時出力はTMPDIR、保存rawはtarとJSONLに集約した。本文・図・外部のLinearKnot/LinearCParty・既存planは変更せず、qsub・git commitは行っていない。
'''
with (ROOT.parent / 'docs/progress.md').open('a') as f:
    f.write(japanese)
print(json.dumps(dict(comparisons=378, byte_identical=summary['byte_identical'],
    all_identical_after_metadata_rename=summary['all_identical_after_metadata_rename'],
    other_differences=summary['other_differences']), ensure_ascii=False))
