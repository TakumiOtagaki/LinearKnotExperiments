#!/usr/bin/env bash
#$ -cwd
#$ -S /bin/bash
#$ -j y
#$ -N lcp_smoke
#$ -l cpu_16=1
#$ -l h_rt=00:10:00
#$ -t 1-1
#$ -tc 30
#$ -o /tmp/9069440.1.all.q/pf-pipeline-smoke-22jpoogq/run/scheduler_logs

set -euo pipefail
: "${SGE_TASK_ID:?Run as an SGE array task}"
: "${JOB_ID:?Missing scheduler allocation}"
cd /gs/bs/tga-satolab-gtex/otgk/LinearCPartyPaper/experiments
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
# Optional first argument: --resume (submit only the interrupted task range).
exec "${LCP_PYTHON:-python3}" scripts/run_array_task.py \
  --plan /tmp/9069440.1.all.q/pf-pipeline-smoke-22jpoogq/run/array_plan.json \
  --tier smoke "$@"
